//
//  FunctionalView.swift
//  ShrodingerEquation
//
//  Created by Whit Castiglioni on 3/12/21.
//

import Foundation
import SwiftUI
import CorePlot

struct FunctionalView: View {
    @ObservedObject private var functionalCalculator = ShootingMethod(withData: true)
    @EnvironmentObject var plotDataModel :PlotDataClass

    //@State var pi = 0.0
    @State var totalGuesses = 0.0
    @State var totalIntegral = 0.0
    @State var domainLimit = 1.0
    @State var guessString = "23458"
    @State var totalGuessString = "0"
    @State var eXString = "0.0"
    
    //var plotDataModel: PlotDataClass? = nil

    
    // Setup the GUI to monitor the data from the Monte Carlo Integral Calculator
    //@ObservedObject var monteCarlo = MonteCarloEulersNumber(withData: true)
    
    //Setup the GUI View
    var body: some View {
        HStack{
            CorePlot(dataForPlot: $plotDataModel.plotData, changingPlotParameters: $plotDataModel.changingPlotParameters)
                .setPlotPadding(left: 10)
                .setPlotPadding(right: 10)
                .setPlotPadding(top: 10)
                .setPlotPadding(bottom: 10)
                .padding()
            VStack{
                
                VStack(alignment: .center) {
                    Text("Guesses")
                        .font(.callout)
                        .bold()
//                    TextField("# Guesses", text: $guessString)
//                        .padding()
                }
                .padding(.top, 5.0)
              
                Button("Cycle Calculation", action: {self.calculateFunctional() })
                    .padding()
//
//                Button("Clear", action: {self.clear()})
//                    .padding(.bottom, 5.0)
                
                
            }
            .padding()
            
            //DrawingField
            

            // Stop the window shrinking to zero.
            Spacer()
            
        }
    }
    func calculateFunctional() {
        functionalCalculator.plotDataModel = self.plotDataModel
        functionalCalculator.shootingProgression()
    }
    
}

struct FunctionalView_Previews: PreviewProvider {
    static var previews: some View {
        FunctionalView()
    }
}
 
//pass the plotDataModel to the cosCalculator
//calculator.plotDataModel = self.plotDataModel
