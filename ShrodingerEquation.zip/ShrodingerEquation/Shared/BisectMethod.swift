//
//  BisectMethod.swift
//  ShrodingerEquation
//
//  Created by Whit Castiglioni on 3/19/21.
//

import Foundation
import SwiftUI
import CorePlot

class BisectMethod: NSObject, ObservableObject {
    //@ObservedObject var ShootingSolution = ShootingMethod(withData: true)
    //ShootingSolution.
    
}
