//
//  ShootingMethod.swift
//  ShrodingerEquation
//
//  Created by Whit Castiglioni on 3/12/21.
//

import Foundation
import SwiftUI
import CorePlot

class ShootingMethod: NSObject, ObservableObject {
    var plotDataModel: PlotDataClass? = nil

    @Published var shootingPoints = [(Energy: Double, psi: Double)]()
    init(withData data: Bool){
        
        super.init()
        
        shootingPoints = []
        //outsideData = []
        
    }
    // A * f() = f''() = Q'()
    // constant * func = double space diritive function = single dirivitive of new func
    //vars of _F representing the result of the function from a var with the same name but with a _X at the end
    
    @Published var initalValue_X = 0.0
    @Published var initalValue_F = 0.8
    @Published var boundryValue_X = 10.0
    @Published var boundryValue_F = 0.0
    @Published var hBar = 1.0
    @Published var mass = 1.0
    @Published var energy = 1.0
    @Published var potential = 0.0
    @Published var aConstant = -7.6201028 //ev Å //h-bar^2 /mass(e)
    @Published var maxEnergy = 40.0
    @Published var distaceStep = 0.02
    @Published var energyInitalAttempt = 0.0
    @Published var energyStep =  0.05
    @Published var ShrodingerSolutions = [Double]()
    
    @Published var potentialArray: [Double] = []
    
    @Published var tolerance = 1E-8

    lazy var psi_i = initalValue_F

    //switchs value when sign switches

    @Published var pointData = [(energy: Double, psi: Double, sign: Int)]()


    
    func shootingProgression() {
        //inital_X:Double, inital_F:Double, boundry_X:Double, boundry_F:Double , stepSize: Double
        var plotData :[plotDataType] =  []

        //plotDataModel!.zeroData()
        
        plotDataModel!.changingPlotParameters.yMax = 2.0
        plotDataModel!.changingPlotParameters.yMin = -2.0
        plotDataModel!.changingPlotParameters.xMax = 10.0 //maxEnergy
        plotDataModel!.changingPlotParameters.xMin = -1.0
        plotDataModel!.changingPlotParameters.xLabel = "Energy (eV)"
        plotDataModel!.changingPlotParameters.yLabel = "Functinal"
        plotDataModel!.changingPlotParameters.lineColor = .red()
        plotDataModel!.changingPlotParameters.title = "Functinal vs Energy"
        
        squarePotential()
        //Parabolic_xSquared(scale: 0.0005)
        
        //var psi_i = initalValue_F
        var Q_psiSlope = 0.01
        
        for energyIncrement in stride(from: energyInitalAttempt, through: maxEnergy, by: energyStep ) {
            var psiIncrement = ShootingMethodFunc(Energy: energyIncrement)
//            var Q_psiSlope = 0.1
//            var distanceIndex = 0
//            psi_i = initalValue_F
//            for distanceIncrement in stride(from: initalValue_X, through: (boundryValue_X), by: (distaceStep) ) {
//                let tempPotential = potentialArray[distanceIndex]
//               // print("index: " + String(tempPotential) + "   Value: " + String(tempPotential))
//                let Q_Slope = 2.0 * distaceStep * (energyIncrement - tempPotential) / aConstant
//                distanceIndex += 1
//                let Q_new = Q_psiSlope + Q_Slope * psi_i
//                psi_i = psi_i + Q_psiSlope * distaceStep
//                Q_psiSlope = Q_new
//                //print("psi: " + String(psi_i) + "  Q_The Slope: " + String(Q_psiSlope))
//                //print("Energy: " + String(energyIncrement))
//            }
            var tempSign: Int
            if psiIncrement > 0 {
                tempSign = 1
            }
            else{
                tempSign = -1
            }
            let shrodingerEquationSolution = (energy: energyIncrement, psi: psiIncrement, sign: tempSign)
            pointData.append(shrodingerEquationSolution)
            let dataPoint: plotDataType = [.X: energyIncrement, .Y: (psi_i)]
            plotData.append(contentsOf: [dataPoint])

        }
        plotDataModel!.appendData(dataPoint: plotData)
        //print(pointData)
        bicectMethod()
    }

    func squarePotential() {
        let totalDistance = boundryValue_X - initalValue_X
        //Fix non interger step error
        let totaldistanceSteps = Int(totalDistance / distaceStep)
        potentialArray.append(1000000.0)
        for a in 2...totaldistanceSteps {
            potentialArray.append(0.0)
        }
        potentialArray.append(1000000.0)
    }
    func Parabolic_xSquared(scale: Double) {
        let totalDistance = boundryValue_X - initalValue_X
        let totaldistanceSteps = Int(totalDistance / distaceStep)
        let totaldistanceStepsToZero = Int(totaldistanceSteps/2)
        for stepsFromTheLeft in 0...totaldistanceSteps {
            potentialArray.append(scale * pow(Double(stepsFromTheLeft - totaldistanceStepsToZero), 2.0))
            //print(potentialArray[stepsFromTheLeft])
        }
    }
    func bicectMethod() {
        let numberOfSolutions = pointData.count
        var tempEng = -7.0
        //previos data initallized
        //var lastPsiValue = pointData[0]
        var lastPsiSign = pointData[0].sign
        print(" lastPsiSign:" + String(lastPsiSign))

        var nextPsiSign = pointData[1].sign
        print(" nextPsiSign:" + String(nextPsiSign))
        
        var lastPsiArrayIndex = 0
        //for solutionNumber in pointData {
        for lastPsiArrayIndex in stride(from: 0, to: (numberOfSolutions - 1), by: 1){
            
            if (pointData[lastPsiArrayIndex].sign != pointData[lastPsiArrayIndex + 1].sign) && lastPsiArrayIndex<(numberOfSolutions-1) {
                var newPsi = pointData[lastPsiArrayIndex].psi
                var lastEnergy = pointData[lastPsiArrayIndex].energy
                var nextEnergy = pointData[lastPsiArrayIndex + 1].energy
                repeat{
                    //print(" lastEnergy:" + String(lastEnergy) + "  psi:" + String(pointData[lastPsiArrayIndex].psi))
                    //print(" nextEnergy:" + String(nextEnergy) + "  psi:" + String(pointData[lastPsiArrayIndex + 1].psi))

                    var newEnergy = (lastEnergy + nextEnergy) / 2.0
                    //print(" newEnergy:" + String(newEnergy))

                    newPsi = ShootingMethodFunc(Energy: newEnergy)
                    //print(" newPsi:" + String(newPsi))

                    var newSign = 0
                    if newPsi>0 {
                        newSign = 1
                    }
                    else{
                        newSign = -1
                    }
                    if pointData[lastPsiArrayIndex].sign == newSign {
                        lastEnergy = newEnergy
                    }
                    else{
                        nextEnergy = newEnergy
                    }
                    tempEng = newEnergy
                    //print(" newPsi" + String(newPsi))
                } while abs(newPsi) > 5E-8 //5E-13
                print("ENG:" + String(tempEng) + "  psi:" + String(newPsi))
            }
            //lastPsiArrayIndex += 1
        }
    }
    func ShootingMethodFunc(Energy: Double)-> Double  {
        var energyIncrement = Energy
        var Q_psiSlope = 0.1
        var distanceIndex = 0
        psi_i = initalValue_F
        for distanceIncrement in stride(from: initalValue_X, through: (boundryValue_X), by: (distaceStep) ) {
            let tempPotential = potentialArray[distanceIndex]
           // print("index: " + String(tempPotential) + "   Value: " + String(tempPotential))
            let Q_Slope = 2.0 * distaceStep * (energyIncrement - tempPotential) / aConstant
            distanceIndex += 1
            let Q_new = Q_psiSlope + Q_Slope * psi_i
            psi_i = psi_i + Q_psiSlope * distaceStep
            Q_psiSlope = Q_new
            //print("psi: " + String(psi_i) + "  Q_The Slope: " + String(Q_psiSlope))
            //print("Energy: " + String(energyIncrement))
        }
        return psi_i
    }
} 


