//
//  ShrodingerEquationApp.swift
//  Shared
//
//  Created by Whit Castiglioni on 3/12/21.
//

import SwiftUI

@main
struct ShrodingerEquationApp: App {
    
    @StateObject var plotDataModel = PlotDataClass(fromLine: true)
    
    var body: some Scene {
        WindowGroup {
            TabView {
                FunctionalView()
                    .environmentObject(plotDataModel)
                    .tabItem {
                        Text("Plot")
                    }
                TextView()
                    .environmentObject(plotDataModel)
                    .tabItem {
                        Text("Text")
                    }
                            
                            
            }
            
        }
    }
}
